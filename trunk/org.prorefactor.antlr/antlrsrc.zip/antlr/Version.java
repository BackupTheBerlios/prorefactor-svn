package antlr;

public class Version {  
	public static final String version    = "2";
	public static final String subversion = "7";
	public static final String patchlevel = "5rc2";
	public static final String datestamp  = "2005-01-08";
	public static final String project_version = "2.7.5rc2 ("+datestamp+")";
}
